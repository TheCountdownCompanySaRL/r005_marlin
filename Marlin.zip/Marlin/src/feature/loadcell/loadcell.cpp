#include "loadcell.h"

#if ENABLED(LOADCELL_FEATURE)

    int16_t ForceSensor::raw = 0;
    float   ForceSensor::forceN = 0;

    void ForceSensor::init() {
        SET_INPUT(LOADCELL_PIN);
    }

    void ForceSensor::update() {
        raw = analogRead(LOADCELL_PIN);

        // Convert ADC (0–1023) → Voltage
        float volts = (raw / 1023.0f) * 5.0f;

        forceN = (volts * 0.4f - 1.0f)*9.81; //offset because bi-directional in range 0-5v to -1 to 1 kg
    }

    float ForceSensor::getForce() {
        return forceN;
    }

    ForceSensor forceSensor;

#endif // FORCE_SENSOR_FEATURE
