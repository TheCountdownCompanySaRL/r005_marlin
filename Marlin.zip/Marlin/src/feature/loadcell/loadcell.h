#pragma once

#include "../../inc/MarlinConfig.h"

#if ENABLED(LOADCELL_FEATURE)

#define LOADCELL_PIN AUX_03_PIN // Analog input A5 on arduino mega

class ForceSensor {
public:
  static void init();      // setup pin
  static void update();    // read ADC, convert to Newtons
  static float getForce(); // latest reading in N
private:
  static int16_t raw;
  static float   forceN;
};

extern ForceSensor forceSensor;

#endif // FORCE_SENSOR_FEATURE
